import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import openSocket from 'socket.io-client';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import {Admin} from './Admin';
class App extends Component {

 socket=null;
  constructor(props)
  {
    super(props);
    this.state={}
    this.sendNotifications=this.sendNotifications.bind(this);
   this.socket = openSocket('http://localhost:8000'); //server ip and listening port

  }
  sendNotifications(person){
    //console.log(this.socket);
    // socket.on('timer', timestamp => cb(null, timestamp));
    this.socket.emit('subscribeToNotify', person,'NotificationSender');
    
  }

  render() {
    return (
      <div className="App">
      <Router>
    <div>
      <ul>
  
        
        <li>
          <Link to="/recieve">ADMIN</Link>
        </li>
      </ul>

      <hr />
      <input type="button" onClick={()=>this.sendNotifications('admin')} value='SendNotifications'/>
     
      <div>
      <Route path="/recieve" component={Admin} />
      </div>
    </div>
  </Router>
        
     
        
      </div>
    );
  }
}

export default App;
