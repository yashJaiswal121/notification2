import React, { Component } from 'react';
import openSocket from 'socket.io-client';

export class Admin extends Component {

    socket=null;
     Notifications=[];
     constructor(props)
     {
       super(props);
       this.state={}
      this.socket = openSocket('http://localhost:8000'); //server ip and listening port
    
     this.checkNotifications=this.checkNotifications.bind(this);
     
     }
     displayedNotificationCounter=0
     checkNotifications(){
        
         this.socket.on('notifications', obj => {
          //  console.log(obj)   //  callback 
                if(obj.length>0){


                   this.Notifications=obj;
                   
                }

                });
            
         this.socket.emit('subscribeToNotify', 'admin','NotificationReciever');

         //displaying notifications as alert.....

         for(var i=this.displayedNotificationCounter;i<this.Notifications.length;i++){
             alert(this.Notifications[i]["date"]);
             console.log(this.Notifications[i]["date"]);
             this.displayedNotificationCounter=++i;
         }

      //  alert(this.Notifications[this.Notifications.length-1]["date"]);


     }
     
     render(){
        
        setInterval(()=>{
            this.checkNotifications()
          },2000);
       // this.checkNotifications();
        return(<div>
            In Admin
        </div>);

     }

     
    }   
   