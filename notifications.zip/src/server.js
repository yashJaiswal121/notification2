

const io = require('socket.io')();

var notification=[];

var clicked=0;
var count=0;
io.on('connection', (client) => {
  console.log("A socket is connected...");
    client.on('subscribeToNotify', (person,endd) => {
      if(endd==='NotificationSender'){
         
        console.log('client is sending notification  to ', person);
        notification.push({date:++count,to:person});
        if(notification.length>=20)
        {     
                //db connection to save the notifications in table
                notification=[];

        }
       
       
      }
      if(endd==='NotificationReciever'){
        console.log(person,'is requesting updated notifications'); 
          // var toSendNotifications=notification.map(x=>{
          //   if(x.to===person){
          //     return x;
          //   }
          // });
          var toSendNotifications=[];
          for(var i=0;i<notification.length;i++)
          {
            if(notification[i].to===person){
              toSendNotifications.push(notification[i]);
            }
          }
      
        client.emit('notifications', toSendNotifications);
        
        
      }
    
  });
})

  const port = 8000;
  io.listen(port);
  console.log('listening on port ', port);

 